# Codex Cloud Starter Guide

A simple guide for beginners who want to connect a GitHub repository to Codex Cloud and let Codex work on it online.

> This guide connects a repository to Codex Cloud. It does **not** deploy an application to Production.

## What you get

After setup, you can:

- Ask Codex to read and understand your GitHub project
- Let Codex edit code in a cloud workspace
- Run tests and checks without keeping your computer online
- Continue work from another computer or phone
- Keep project history safely in GitHub
- Review changes before you commit, push, or deploy anything

## What you need

- A Codex account
- A GitHub account
- One GitHub repository

**You do not need to install extra skills to begin.**

## The easiest setup

### 1. Create a GitHub repository

Go to [GitHub](https://github.com/new) and create a repository.

Choose:

- **Private** for personal projects
- **Public** only when everything is safe for anyone to see
- Enable **Add a README**

### 2. Connect GitHub to Codex

In Codex, choose the option to connect GitHub or select a repository.

GitHub will ask you to authorize the Codex/OpenAI GitHub app.

### 3. Give Codex access to the repository

In GitHub:

1. Open **Settings**
2. Open **Applications**
3. Open **Installed GitHub Apps**
4. Find the Codex/OpenAI integration
5. Select **Configure**
6. Choose **Only select repositories**
7. Select the repository you created
8. Save

Each person has a different GitHub installation URL, so do not copy another person's numeric installation link.

### 4. Open the repository in Codex Cloud

Return to Codex Cloud and create a cloud task.

Select your connected GitHub repository.

If the repository does not appear:

- Confirm that you connected the correct GitHub account
- Confirm that the repository is selected in the GitHub app settings
- Refresh or reconnect Codex
- Ask an organization administrator for approval if the repository belongs to an organization

### 5. Run a safe first test

Paste this prompt:

```text
Open and inspect this repository.

Tell me:
- the current branch
- the repository status
- the important files and folders
- what programming language or framework it uses
- what tests or checks are available

Do not modify any file.
Do not install anything.
Do not commit, push, create a pull request, or deploy.
```

If Codex can report the repository correctly, your Codex Cloud connection is working.

## Ask AI to use this starter guide

Paste this into Codex:

```text
Use this beginner guide as a reference:
https://github.com/programmermars/codex-cloud-starter-guide

Read README.md and AGENTS.md.

Then inspect my current repository and explain, in simple steps:
1. whether GitHub is connected correctly
2. whether Codex Cloud can access the repository
3. what setup is still missing
4. what my safest first task should be

Do not modify files, install software, commit, push, create a pull request, or deploy.
Finish with one clear next action for me.
```

## Your first work prompt

After the connection test succeeds:

```text
Read AGENTS.md first.

Task:
[Describe one small change.]

Expected result:
[Describe what should work when finished.]

Please:
- inspect the relevant files
- make only the requested change
- run the available tests
- explain what changed

Do not commit, push, create a pull request, or deploy.
```

Ask for a commit or push only after you review the result.

## Why use this repository?

Beginners often do not know:

- Which account must be connected
- Why their repository does not appear in Codex Cloud
- Whether Codex is allowed to change files
- How to test the connection safely
- What to put in the first prompt
- How to prevent accidental commits or deployments

This repository gives them:

- One short setup path
- Copy-and-paste prompts
- A reusable `AGENTS.md`
- Clear safety boundaries
- Troubleshooting for missing repository access

## What is AGENTS.md?

`AGENTS.md` contains reusable instructions for Codex.

Because the rules live inside the repository, you do not need to repeat the same long instructions in every prompt.

Keep it short and include only stable rules such as:

- Inspect before editing
- Do not expose secrets
- Run available tests
- Avoid unrelated changes
- Commit, push, create a pull request, or deploy only when explicitly requested

## Are skills required?

No. Start with the normal GitHub connection and repository tools.

Install a skill only when you later need specialized work, such as:

- Fixing GitHub Actions
- Editing spreadsheets or documents
- Testing a website in a browser
- Using current OpenAI documentation

Installing many unnecessary skills can make the setup more confusing.

## Important safety rules

Never put these in GitHub:

- Passwords
- API keys or access tokens
- `.env` files
- Private keys
- Personal records
- Confidential employer or customer information
- Internal URLs or documents you are not allowed to copy

A private repository controls access, but it does not make prohibited information safe to upload.

## Simple workflow to remember

```text
Create repository
        ↓
Connect GitHub to Codex
        ↓
Select repository in GitHub App settings
        ↓
Open repository in Codex Cloud
        ↓
Run a read-only test
        ↓
Ask for one small change
        ↓
Review and test
        ↓
Commit or deploy only when ready
```

## Official help

- [OpenAI Developers](https://developers.openai.com/)
- [OpenAI Codex use cases](https://developers.openai.com/codex/use-cases)
- [GitHub documentation](https://docs.github.com/)

## Contributing

Beginner-friendly improvements are welcome. Use only public-safe examples and never submit credentials or private information.
