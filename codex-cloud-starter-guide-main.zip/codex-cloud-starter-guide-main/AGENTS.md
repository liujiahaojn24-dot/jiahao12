# AGENTS.md

## Purpose

Help beginners use Codex Cloud safely. GitHub is the source of truth.

## Before changes

1. Run `git status --short --branch`.
2. Inspect relevant files before editing.
3. Preserve uncommitted user work.
4. Never expose or commit secrets.

## Editing

- Make the smallest coherent change.
- Follow existing conventions.
- Avoid unrelated refactors.
- Keep all examples public-safe.

## Validation

Run the relevant lint, tests, typecheck, and build commands available in the repository. Report skipped checks and why.

## Git safety

- Inspect `git diff` before committing.
- Never overwrite uncommitted user changes.
- Never force-push unless explicitly requested.
- Commit, push, create a pull request, or deploy only when explicitly requested.
- Never deploy to Production without explicit authorization.

## Completion report

Report changes made, files changed, checks run, pass/fail results, Git status, commit hash if created, deployment result, and anything requiring user action.
